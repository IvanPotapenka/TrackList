//
//  DatailViewController.swift
//  TrackList
//
//  Created by asus on 2/9/21.
//  Copyright © 2021 Ivan Potapenko. All rights reserved.
//

import UIKit

class DatailViewController: UIViewController {

   
    @IBOutlet var image: UIImageView!
    
    @IBOutlet var nameTrack: UILabel!
    
    var nameImage: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        image.image = UIImage(named: nameImage)
        nameTrack.text = nameImage
        nameTrack.numberOfLines = 0
    }
    
}
