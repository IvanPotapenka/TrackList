//
//  TrackListViewController.swift
//  TrackList
//
//  Created by asus on 2/9/21.
//  Copyright © 2021 Ivan Potapenko. All rights reserved.
//

import UIKit

class TrackListViewController: UITableViewController {

    let tracks = [
        
        "Tiёsto - The Business",
        "Meduza feat Dermot Kennedy - Paradise",
        "Ed Sheeran - Afterglow",
        "Jason Derülo - Take You Dancing",
        "Foushee - Deep End",
        "Nea and Nio Garcia - Diablo",
        "Marshmello and Imanbek, Usher - Too Much",
        "Billie Eilish - Therefore I Am",
        "David Guetta Feat Sia - Let's Love",
        "Paolo Pellegrino and N.f.i, Shanguy - Oops (Go Back To Your Ex",
        "Ava Max - My Head and My Heart",
        "Zivert - Многоточия",
        "Alok feat Ilkay Sencan, Tove Lo - Don't Say Goodbye",
        "Michael Patrick Kelly - Beautiful Madness",
        "Joel Corry and Mnek - Head and Heart",
        "Billie Eilish - Everything I Wanted",
        "Moses feat Emr3ygul, Alexiane - A Million on My Soul (Remix",
        "Hurts - Redemption",
        "Hammali feat Мари Краймбрери - Медляк",
        "Bastard! - Fuck That",
        "The Weeknd - Save Your Tears",
        "Ya Rick feat Kddk - La Grenade",
        "Pascal Letoublon - Friendships"]


    // MARK: - Table view data source

   override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    
        return tracks.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TrackName", for: indexPath)
        
        cell.textLabel?.text = tracks[indexPath.row]
        
        cell.textLabel?.numberOfLines = 0
        
        cell.imageView?.image = UIImage(named: tracks[indexPath.row])
        
        return cell
    }
   

    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard segue.identifier == "goToDatailVC" else { return }
        guard let destenation = segue.destination as? DatailViewController else { return }
        guard let indexPath = tableView.indexPathForSelectedRow else { return }
        destenation.nameImage = tracks[indexPath.row]
    }

}
